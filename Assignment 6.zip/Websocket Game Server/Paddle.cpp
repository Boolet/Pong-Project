#include "Paddle.hpp"

/*
void Paddle::onCollision(Bounds* other, side onSide){
    Bounds::onCollision(other, onSide);
    
    if(paddleScore != nullptr && other->getName() == "ball"){
        paddleScore->score += 1;
    }
}
*/
